
"use client";
import { Carousel } from "@/components/ui/carousel";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Script from "next/script";
import { useState } from "react";

export default function Home() {
  const [submitted, setSubmitted] = useState(false);

  return (
    <div className="p-4 space-y-10 max-w-screen-xl mx-auto">
      <Script
        strategy="lazyOnload"
        src="https://embed.tawk.to/64ecf0ed94cf5d49dc6a719e/1h8r8i94t"
        crossOrigin="*"
      />

      <section className="text-center bg-gray-100 py-10 rounded-2xl shadow-md">
        <img
          src="/banner-shipping-services.jpg"
          alt="Door to Door Shipping Hero Banner"
          className="mx-auto w-full max-w-5xl rounded-lg"
        />
        <h1 className="text-4xl font-bold mt-6">NIVKART - Global Door-to-Door Logistics</h1>
        <p className="text-lg mt-2">From China to USA for Amazon FBA, Shopify Sellers & Indian Importers</p>
      </section>

      <Carousel className="w-full max-w-5xl mx-auto">
        <Card><CardContent className="p-6"><h2 className="text-2xl font-semibold mb-2">Sourcing & Product Inspection</h2><p>Connect with trusted suppliers, get quality checks done before shipping.</p></CardContent></Card>
        <Card><CardContent className="p-6"><h2 className="text-2xl font-semibold mb-2">China Warehouse Services</h2><p>Consolidation, labeling, and short-term warehousing facilities.</p></CardContent></Card>
        <Card><CardContent className="p-6"><h2 className="text-2xl font-semibold mb-2">Air & Sea Freight</h2><p>Choose from cost-effective sea freight or fast air shipping options.</p></CardContent></Card>
        <Card><CardContent className="p-6"><h2 className="text-2xl font-semibold mb-2">Customs Clearance</h2><p>Hassle-free clearance and compliance support in China and USA.</p></CardContent></Card>
        <Card><CardContent className="p-6"><h2 className="text-2xl font-semibold mb-2">Amazon FBA Prep & Delivery</h2><p>Labeling, bundling, and delivery to Amazon warehouses across the US.</p></CardContent></Card>
        <Card><CardContent className="p-6"><h2 className="text-2xl font-semibold mb-2">Shopify Fulfillment</h2><p>Direct-to-customer shipping support for your Shopify stores.</p></CardContent></Card>
      </Carousel>

      <section className="text-center mt-10">
        <h2 className="text-3xl font-bold mb-4">Get a Free Quote</h2>
        {!submitted ? (
          <form
            className="space-y-4 max-w-xl mx-auto"
            action="https://script.google.com/macros/s/YOUR_GOOGLE_SCRIPT_ID/exec"
            method="POST"
            target="hidden_iframe"
            onSubmit={() => setSubmitted(true)}
          >
            <input name="name" type="text" placeholder="Your Name" className="w-full border p-2 rounded" required />
            <input name="email" type="email" placeholder="Email Address" className="w-full border p-2 rounded" required />
            <input name="query" type="text" placeholder="What do you want to ship?" className="w-full border p-2 rounded" required />
            <Button type="submit" className="w-full">Submit</Button>
          </form>
        ) : (
          <div className="text-green-600 font-semibold text-lg">Thank you! Your details have been submitted successfully.</div>
        )}
        <iframe name="hidden_iframe" style={{ display: 'none' }}></iframe>
      </section>
    </div>
  );
}
